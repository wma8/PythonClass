#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 01:22:37 2018

@author: hangjieji
"""

def main():
    print "main() is running"

print "example2 is running"

main()