def filter(haystack, needles):
    return [x for x in haystack if x in needles]