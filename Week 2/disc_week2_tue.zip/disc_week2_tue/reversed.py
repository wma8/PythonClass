def reversed(l):
    return [l[-i-1] for i in range(len(l))]